"""
Extrage features lexicale per cuvant din test_set.
Combina cu ET features si produce matricea X de features pentru modelare.
"""
import re
import math
import pandas as pd
import numpy as np
from wordfreq import word_frequency, zipf_frequency

DATA_DIR = r"C:\Users\glosper\Documents\pred_eye\data"

VOWELS_RO = set('aeiouăâî')


def normalize_token(w: str) -> str:
    w = str(w).strip()
    w = re.sub(r'^[„""\'\"({\[«»\-–—]+', '', w)
    w = re.sub(r'[.,;:!?\)\]}"\'\"»–—]+$', '', w)
    return w.strip()


def count_syllables(word: str) -> int:
    """Estimare silabe romana: numara grupuri de vocale consecutive."""
    word = word.lower()
    syllables = 0
    prev_vowel = False
    for ch in word:
        if ch in VOWELS_RO:
            if not prev_vowel:
                syllables += 1
            prev_vowel = True
        else:
            prev_vowel = False
    return max(1, syllables)


def has_diacritice(word: str) -> bool:
    return any(c in 'ăâîșțşţ' for c in word)


def get_freq_features(token: str, lemma: str, lang: str = 'ro') -> dict:
    """Frecventa din wordfreq pentru token si lemma."""
    tok_clean = normalize_token(token).lower()
    lem_clean = normalize_token(lemma).lower()

    zipf_tok = zipf_frequency(tok_clean, lang)
    zipf_lem = zipf_frequency(lem_clean, lang)
    # Ia maximul (forma mai frecventa)
    zipf_best = max(zipf_tok, zipf_lem)
    # Zipf 0 = necunoscut; ii dam o valoare mica (cuvant rar)
    zipf_best_filled = zipf_best if zipf_best > 0 else 2.0
    zipf_tok_filled = zipf_tok if zipf_tok > 0 else 2.0

    return {
        'zipf_token': zipf_tok,
        'zipf_lemma': zipf_lem,
        'zipf_best': zipf_best,
        'zipf_best_filled': zipf_best_filled,
        'neg_zipf': -zipf_best_filled,     # invers: mai mic = mai complex
        'is_oov': int(zipf_tok == 0),
        'freq_token': word_frequency(tok_clean, lang),
        'log_freq': math.log(word_frequency(tok_clean, lang) + 1e-10),
    }


def compute_lexical_features(token: str, lemma: str) -> dict:
    """Features ortografice, morfologice si de frecventa."""
    tok_clean = normalize_token(token)
    lem_clean = normalize_token(lemma)

    tok_len = len(tok_clean)
    lem_len = len(lem_clean)
    syl = count_syllables(tok_clean)

    base = {
        'word_length': tok_len,
        'lemma_length': lem_len,
        'num_syllables': syl,
        'avg_syllable_length': tok_len / syl,
        'num_vowels': sum(1 for c in tok_clean.lower() if c in VOWELS_RO),
        'num_consonants': sum(1 for c in tok_clean.lower() if c.isalpha() and c not in VOWELS_RO),
        'has_diacritice': int(has_diacritice(tok_clean)),
        'has_hyphen': int('-' in token),
        'is_capitalized': int(token[0].isupper()) if token else 0,
        'vowel_ratio': sum(1 for c in tok_clean.lower() if c in VOWELS_RO) / max(1, tok_len),
        'inflection_diff': abs(tok_len - lem_len),
        'ends_with_vowel': int(tok_clean[-1].lower() in VOWELS_RO) if tok_clean else 0,
    }
    base.update(get_freq_features(token, lemma))
    return base


def minmax_norm(series: pd.Series) -> pd.Series:
    mn, mx = series.min(), series.max()
    if mx == mn:
        return pd.Series(0.5, index=series.index)
    return (series - mn) / (mx - mn)


def build_et_complexity_proxy(test_aligned: pd.DataFrame) -> pd.Series:
    """
    Calculeaza un scor de complexitate bazat pe ET metrics (normalizate MinMax).
    Cuvintele fara ET features primesc NaN.
    Scor mai mare = cuvant mai complex.
    """
    df = test_aligned.copy()

    # Indicatori ET relevanti pentru complexitate (din literatura)
    has_et = df['TFT_mean'].notna()

    # MinMax normalizare pe coloana intreaga (inclusiv NaN ignorate)
    def norm_col(col):
        return minmax_norm(df.loc[has_et, col])

    et_score = pd.Series(np.nan, index=df.index)

    if has_et.sum() > 0:
        # Compunere ponderata bazata pe relevanta in literatura
        scores = pd.DataFrame(index=df[has_et].index)
        scores['tft']      = norm_col('TFT_mean')      * 0.30  # total fixation time
        scores['rrt']      = norm_col('RRT_mean')       * 0.20  # re-reading time
        scores['ffd']      = norm_col('FFD_mean')       * 0.15  # first fixation duration
        scores['rpd']      = norm_col('RPD_inc_mean')   * 0.10  # regression path
        scores['trc_in']   = norm_col('TRC_in_mean')    * 0.08  # regressions in
        scores['fpfc']     = norm_col('FPFC_mean')      * 0.07  # first pass fixation count
        scores['tfc']      = norm_col('TFC_mean')       * 0.05  # total fixation count
        # skip_rate invers: cuvintele sarite des sunt SIMPLE
        scores['skip_inv'] = (1 - norm_col('skip_rate')) * 0.05

        et_score[has_et] = scores.sum(axis=1)

    return et_score


def build_feature_matrix(test_aligned: pd.DataFrame) -> pd.DataFrame:
    """
    Construieste matricea completa de features combinand ET si lexical.
    """
    print("Calcul features lexicale ...")
    lex_features = test_aligned.apply(
        lambda row: compute_lexical_features(str(row['token']), str(row['lemma'])),
        axis=1
    )
    lex_df = pd.DataFrame(list(lex_features))

    print("Calcul ET complexity proxy ...")
    et_proxy = build_et_complexity_proxy(test_aligned)
    lex_df['et_complexity_proxy'] = et_proxy.values
    lex_df['has_et_features'] = test_aligned['TFT_mean'].notna().astype(int).values

    # ET features principale (normalizate)
    et_cols = ['TFT_mean', 'FFD_mean', 'FPRT_mean', 'RRT_mean',
               'TFC_mean', 'FPFC_mean', 'TRC_in_mean', 'RPD_inc_mean',
               'TFT_std', 'FFD_std', 'skip_rate', 'refixation_rate',
               'ffd_fprt_ratio', 'tft_per_fixation', 'TFT_cv']

    for col in et_cols:
        if col in test_aligned.columns:
            vals = test_aligned[col].values.astype(float)
            col_series = pd.Series(vals)
            norm_vals = minmax_norm(col_series.dropna())
            result = pd.Series(np.nan, index=range(len(test_aligned)))
            result[col_series.notna()] = norm_vals.values
            lex_df[f'{col}_norm'] = result.values

    lex_df['datapointID'] = test_aligned['datapointID'].values
    lex_df['text_name'] = test_aligned['text_name'].values
    lex_df['token'] = test_aligned['token'].values

    return lex_df


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')

    print("=== Build Feature Matrix ===")
    test_aligned = pd.read_csv(f"{DATA_DIR}/test_aligned.csv")
    calib_aligned = pd.read_csv(f"{DATA_DIR}/calib_aligned.csv")

    print(f"\nTest set: {len(test_aligned)} randuri")
    print(f"  Cu ET features: {test_aligned['TFT_mean'].notna().sum()}")
    print(f"  Fara ET features: {test_aligned['TFT_mean'].isna().sum()}")

    # Feature matrix pentru test
    X_test = build_feature_matrix(test_aligned)
    X_test.to_csv(f"{DATA_DIR}/X_test.csv", index=False)
    print(f"\nSalvat X_test.csv: {X_test.shape}")

    # Feature matrix pentru calibrare (14 exemple)
    # Adaugam dummy columns pentru alignment daca lipsesc
    for col in test_aligned.columns:
        if col not in calib_aligned.columns:
            calib_aligned[col] = np.nan

    X_calib = build_feature_matrix(calib_aligned)
    X_calib['complexity'] = calib_aligned['complexity'].values
    X_calib.to_csv(f"{DATA_DIR}/X_calib.csv", index=False)
    print(f"Salvat X_calib.csv: {X_calib.shape}")

    print("\n--- Statistici features cheie pe calibrare ---")
    show_cols = ['token', 'word_length', 'num_syllables', 'et_complexity_proxy', 'complexity']
    available = [c for c in show_cols if c in X_calib.columns]
    print(X_calib[available].to_string())
