"""
Alinierea tokenurilor din test_set cu cuvintele din ET data.
Produce: data/word_features.csv — features ET agregate per (text_name, word_norm)
"""
import re
import pandas as pd
import numpy as np

DATA_DIR = r"C:\Users\glosper\Documents\pred_eye\data"


def normalize_token(w: str) -> str:
    """Strip punctuatie de inceput/sfarsit, pastreaza diacritice."""
    w = str(w).strip()
    # Strip ghilimele si semne speciale la inceput
    w = re.sub(r'^[„""\'\"({\[«»\-–—]+', '', w)
    # Strip punctuatie la sfarsit
    w = re.sub(r'[.,;:!?\)\]}"\'\"»–—]+$', '', w)
    return w.strip()


def build_word_features(et_path: str) -> pd.DataFrame:
    """
    Incarca ET data si agregate metricile per (text_name, word_norm).
    Exclude randurile skipped=1 din calculul mediilor, dar calculeaza skip_rate separat.
    """
    print("Incarcare train_et.csv ...")
    et = pd.read_csv(et_path)
    print(f"  {len(et):,} randuri, {et['participant_id'].nunique()} participanti, "
          f"{et['text_name'].nunique()} texte")

    # Normalizare word
    et['word_norm'] = et['word'].apply(normalize_token).str.lower()

    et_metrics = ['TFC', 'FD', 'FFD', 'FPRT', 'FRT', 'RRT', 'FPFC',
                  'TRC_in', 'TRC_out', 'LP', 'SL_in', 'SL_out',
                  'RPD_inc', 'RPD_exc', 'RBRT', 'TFT', 'FPF', 'RR', 'SFD']

    # --- skip_rate per (text_name, word_norm) ---
    skip_rate = (et.groupby(['text_name', 'word_norm'])['skipped']
                   .mean()
                   .rename('skip_rate'))

    # --- nr participanti care au citit cuvantul ---
    n_readers = (et.groupby(['text_name', 'word_norm'])['skipped']
                   .apply(lambda x: (x == 0).sum())
                   .rename('n_readers'))

    # --- Statistici ET (doar randuri ne-sarite) ---
    et_read = et[et['skipped'] == 0].copy()

    agg_mean = (et_read.groupby(['text_name', 'word_norm'])[et_metrics]
                       .mean()
                       .add_suffix('_mean'))

    agg_median = (et_read.groupby(['text_name', 'word_norm'])[et_metrics]
                         .median()
                         .add_suffix('_median'))

    agg_std = (et_read.groupby(['text_name', 'word_norm'])[et_metrics]
                      .std()
                      .fillna(0)
                      .add_suffix('_std'))

    agg_max = (et_read.groupby(['text_name', 'word_norm'])[et_metrics]
                      .max()
                      .add_suffix('_max'))

    # --- Combinare ---
    features = pd.concat([agg_mean, agg_median, agg_std, agg_max,
                          skip_rate, n_readers], axis=1).reset_index()

    # --- Features derivate ---
    eps = 1e-6
    features['refixation_rate'] = features['RR_mean']
    features['regression_in_rate'] = features['TRC_in_mean']
    features['ffd_fprt_ratio'] = features['FFD_mean'] / (features['FPRT_mean'] + eps)
    features['tft_per_fixation'] = features['TFT_mean'] / (features['TFC_mean'] + eps)
    # Coeficient de variatie pentru TFT (variabilitate inter-participanti)
    features['TFT_cv'] = features['TFT_std'] / (features['TFT_mean'] + eps)
    features['FFD_cv'] = features['FFD_std'] / (features['FFD_mean'] + eps)

    print(f"  Features generate: {len(features):,} cuvinte unice (text_name, word_norm)")
    return features


def align_test_with_et(test_path: str, word_features: pd.DataFrame) -> pd.DataFrame:
    """
    Aliniaza test_set.csv cu word_features pe baza (text_name, token).
    Strategie: match exact pe token.lower() == word_norm, fallback pe lemma.
    """
    print("Aliniere test_set cu ET features ...")
    test = pd.read_csv(test_path)
    test['token_norm'] = test['token'].apply(normalize_token).str.lower()
    test['lemma_norm'] = test['lemma'].apply(normalize_token).str.lower()

    # Join 1: exact pe (text_name, token_norm == word_norm)
    merged = test.merge(
        word_features,
        left_on=['text_name', 'token_norm'],
        right_on=['text_name', 'word_norm'],
        how='left'
    )

    matched_exact = merged['TFT_mean'].notna().sum()
    print(f"  Match exact: {matched_exact}/{len(test)} ({100*matched_exact/len(test):.1f}%)")

    # Fallback: pentru ne-matchuite, incearca cu lemma_norm
    unmatched_mask = merged['TFT_mean'].isna()
    if unmatched_mask.sum() > 0:
        fallback = test[unmatched_mask][['text_name', 'lemma_norm', 'datapointID']].merge(
            word_features,
            left_on=['text_name', 'lemma_norm'],
            right_on=['text_name', 'word_norm'],
            how='left'
        )
        # Actualizeaza randurile ne-matchuite
        feat_cols = [c for c in word_features.columns if c not in ['text_name', 'word_norm']]
        for col in feat_cols:
            if col in fallback.columns:
                merged.loc[unmatched_mask, col] = fallback[col].values

        matched_fallback = merged['TFT_mean'].notna().sum() - matched_exact
        print(f"  Match fallback (lemma): {matched_fallback}")

    still_unmatched = merged['TFT_mean'].isna().sum()
    print(f"  Nematched total: {still_unmatched}")
    if still_unmatched > 0:
        print("  Exemple nematched (primele 10):")
        nm = merged[merged['TFT_mean'].isna()][['text_name', 'token', 'token_norm', 'lemma']].head(10)
        for _, row in nm.iterrows():
            print(f"    {row['text_name']} | token={row['token'].encode('ascii','replace').decode()} | norm={row['token_norm'].encode('ascii','replace').decode()} | lemma={row['lemma'].encode('ascii','replace').decode()}")

    return merged


def align_labeled_with_et(labels_path: str, word_features: pd.DataFrame) -> pd.DataFrame:
    """Aliniaza cele 14 exemple etichetate cu ET features."""
    labels = pd.read_csv(labels_path)
    labels['token_norm'] = labels['token'].apply(normalize_token).str.lower()
    labels['lemma_norm'] = labels['lemma'].apply(normalize_token).str.lower()

    merged = labels.merge(
        word_features,
        left_on=['text_name', 'token_norm'],
        right_on=['text_name', 'word_norm'],
        how='left'
    )

    # Fallback pe lemma
    unmatched = merged['TFT_mean'].isna()
    if unmatched.sum() > 0:
        fb = labels[unmatched][['text_name', 'lemma_norm', 'complexity']].merge(
            word_features,
            left_on=['text_name', 'lemma_norm'],
            right_on=['text_name', 'word_norm'],
            how='left'
        )
        feat_cols = [c for c in word_features.columns if c not in ['text_name', 'word_norm']]
        for col in feat_cols:
            if col in fb.columns:
                merged.loc[unmatched, col] = fb[col].values

    matched = merged['TFT_mean'].notna().sum()
    print(f"  Calibrare: {matched}/14 exemple cu ET features")
    return merged


if __name__ == '__main__':
    word_features = build_word_features(f"{DATA_DIR}/train_et.csv")
    word_features.to_csv(f"{DATA_DIR}/word_features.csv", index=False)
    print(f"Salvat: word_features.csv ({len(word_features):,} randuri)")

    test_aligned = align_test_with_et(f"{DATA_DIR}/test_set.csv", word_features)
    test_aligned.to_csv(f"{DATA_DIR}/test_aligned.csv", index=False)
    print(f"Salvat: test_aligned.csv ({len(test_aligned):,} randuri)")

    calib_aligned = align_labeled_with_et(f"{DATA_DIR}/labeled_examples.csv", word_features)
    calib_aligned.to_csv(f"{DATA_DIR}/calib_aligned.csv", index=False)
    print(f"Salvat: calib_aligned.csv ({len(calib_aligned):,} randuri)")
