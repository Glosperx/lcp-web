# Predicția complexității lexicale din date de eye-tracking

## Descriere
Pipeline pentru predicția scorului de complexitate (0–1) al cuvintelor în limba
română, folosind metrici de eye-tracking agregate peste participanți + frecvența
cuvintelor (wordfreq).

## Cerințe
```
pip install pandas numpy scikit-learn scipy wordfreq
```

## Date necesare (în folderul `data/`)
- `train_et.csv`     — metrici eye-tracking per participant (input competiție)
- `test_set.csv`     — cuvintele de prezis (input competiție)
- `labeled_examples.csv` — cele 14 exemple etichetate din enunț (set de calibrare)

## Rulare (în ordine)
```bash
python src/01_alignment.py   # aliniere token test <-> ET + agregare features
python src/02_features.py    # features lexicale + frecvențe (wordfreq)
python src/04_predict.py     # model final + generare submisii
```

## Metodă
1. **Aliniere**: token-urile din `test_set` sunt aliniate cu cuvintele din ET data
   pe `(text_name, token normalizat)`, cu fallback pe lemmă. Match exact ~95%.
2. **ET proxy**: scor compus ponderat din metricile ET (TFT, RRT, FFD, RPD, TRC,
   FPFC, TFC, skip_rate), normalizate pe distribuția corpusului ET.
3. **Frecvență**: `zipf_token` din wordfreq (cel mai puternic predictor singular,
   Pearson = -0.61 cu complexitatea pe setul de calibrare).
4. **Blend + calibrare z-score**: combinație ET proxy + zipf, apoi moment matching
   (medie + deviație standard) la distribuția complexității.

## Output
`output/submission_zscore.csv` — fișierul principal (3 coloane: subtaskID,
datapointID, answer). Scor LOO pe calibrare ≈ 40 (Pearson +0.65, R² 0.15).
