"""
Script final de predictie: genereaza submission.csv
Abordare: Blend(zipf_token, ET_proxy) + calibrare liniara pe 14 exemple
"""
import sys
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import r2_score
from scipy.stats import pearsonr

sys.stdout.reconfigure(encoding='utf-8')

DATA_DIR   = r"C:\Users\glosper\Documents\pred_eye\data"
OUTPUT_DIR = r"C:\Users\glosper\Documents\pred_eye\output"


def eval_metric(y_true, preds):
    y_true = np.array(y_true, dtype=float)
    preds  = np.array(preds,  dtype=float)
    if np.std(preds) < 1e-9:
        return 0.0
    r2 = max(0.0, r2_score(y_true, preds))
    pears, _ = pearsonr(y_true, preds)
    if np.isnan(pears):
        pears = 0.0
    return 100.0 * (abs(pears) + r2) / 2.0


def compute_et_proxy(df_aligned, word_features_df):
    """ET complexity proxy normalizat pe distributia word_features."""
    weights = {
        'TFT_mean': 0.30, 'RRT_mean': 0.20, 'FFD_mean': 0.14,
        'RPD_inc_mean': 0.10, 'TRC_in_mean': 0.08, 'FPFC_mean': 0.07,
        'TFC_mean': 0.05, 'skip_rate': -0.10,
    }
    has_et = df_aligned['TFT_mean'].notna()
    proxy  = pd.Series(np.nan, index=df_aligned.index)
    if has_et.sum() == 0:
        return proxy
    scores = pd.DataFrame(index=df_aligned[has_et].index)
    for col, w in weights.items():
        if col not in df_aligned.columns or col not in word_features_df.columns:
            continue
        mn  = word_features_df[col].quantile(0.01)
        mx  = word_features_df[col].quantile(0.99)
        val = df_aligned.loc[has_et, col].fillna(0)
        if mx == mn:
            norm = pd.Series(0.5, index=val.index)
        else:
            norm = ((val - mn) / (mx - mn)).clip(0, 1)
        scores[col] = norm * abs(w) if w > 0 else (1 - norm) * abs(w)
    proxy[has_et] = scores.sum(axis=1).clip(0, 1)
    return proxy


def build_blend(zipf_vals, et_proxy_vals, has_et_mask,
                et_weight=0.5):
    """
    Combina zipf si ET:
    - daca are ET: blend = et_weight*et + (1-et_weight)*zipf
    - daca nu are ET: blend = zipf
    """
    blend = np.where(has_et_mask,
                     et_weight * et_proxy_vals + (1 - et_weight) * zipf_vals,
                     zipf_vals)
    return blend


def zipf_to_complexity(zipf_arr, ref_min, ref_max):
    """Transforma zipf_token → complexity proxy (invers normalizat)."""
    return 1.0 - np.clip((zipf_arr - ref_min) / (ref_max - ref_min + 1e-9), 0, 1)


def main():
    print("=" * 60)
    print("PREDICTIE FINALA")
    print("=" * 60)

    # --- Incarcare date ---
    test_aligned   = pd.read_csv(f"{DATA_DIR}/test_aligned.csv")
    calib_aligned  = pd.read_csv(f"{DATA_DIR}/calib_aligned.csv")
    X_test_df      = pd.read_csv(f"{DATA_DIR}/X_test.csv")
    X_calib_df     = pd.read_csv(f"{DATA_DIR}/X_calib.csv")
    word_features  = pd.read_csv(f"{DATA_DIR}/word_features.csv")
    test_df        = pd.read_csv(f"{DATA_DIR}/test_set.csv")
    y_calib        = X_calib_df['complexity'].values

    # --- ET proxy ---
    et_proxy_test  = compute_et_proxy(test_aligned,  word_features)
    et_proxy_calib = compute_et_proxy(calib_aligned, word_features)

    # --- Zipf token (feature principal) ---
    zt_test  = X_test_df['zipf_token'].values.astype(float)
    zt_calib = X_calib_df['zipf_token'].values.astype(float)

    # Calibreaza pe distributia TOTALA a datelor de test
    ref_min = np.nanpercentile(zt_test, 1)
    ref_max = np.nanpercentile(zt_test, 99)
    print(f"Zipf test range (p1-p99): {ref_min:.2f} - {ref_max:.2f}")

    zipf_comp_test  = zipf_to_complexity(np.nan_to_num(zt_test,  nan=ref_min), ref_min, ref_max)
    zipf_comp_calib = zipf_to_complexity(np.nan_to_num(zt_calib, nan=ref_min), ref_min, ref_max)

    has_et_test  = et_proxy_test.notna().values
    has_et_calib = et_proxy_calib.notna().values

    et_v_test  = et_proxy_test.fillna(0).values
    et_v_calib = et_proxy_calib.fillna(0).values

    print(f"Test words cu ET: {has_et_test.sum()}/{len(has_et_test)}")
    print(f"Calib words cu ET: {has_et_calib.sum()}/{len(has_et_calib)}")

    # --- Grid search: cel mai bun et_weight ---
    print("\n--- Grid search et_weight ---")
    best_score, best_w = -999, 0.5
    for w in np.arange(0.0, 1.05, 0.1):
        blend_c = build_blend(zipf_comp_calib, et_v_calib, has_et_calib, et_weight=w)
        score = eval_metric(y_calib, np.clip(blend_c, 0, 1))
        pears, _ = pearsonr(y_calib, np.clip(blend_c, 0, 1))
        if score > best_score:
            best_score, best_w = score, w

    print(f"  Cel mai bun et_weight: {best_w:.1f}, Score: {best_score:.2f}")
    blend_calib = np.clip(build_blend(zipf_comp_calib, et_v_calib, has_et_calib, et_weight=best_w), 0, 1)
    blend_test  = np.clip(build_blend(zipf_comp_test,  et_v_test,  has_et_test,  et_weight=best_w), 0, 1)

    pears_blend, _ = pearsonr(y_calib, blend_calib)
    print(f"  Pearson pe calibrare: {pears_blend:+.3f}")

    # =====================================================================
    # CALIBRARE LINIARA PE 14 EXEMPLE
    # Adjusteaza scara predictiei sa corespunda distributiei complexitatii
    # =====================================================================
    print("\n--- Calibrare liniara (fit pe 14 exemple) ---")

    # Fit: complexity ~ a * blend + b
    X_blend_c = blend_calib.reshape(-1, 1)
    ridge_calib = Ridge(alpha=0.1)
    ridge_calib.fit(X_blend_c, y_calib)
    a_calib = ridge_calib.coef_[0]
    b_calib = ridge_calib.intercept_
    print(f"  Calibrare: complexity = {a_calib:.3f} * blend + {b_calib:.3f}")

    pred_test_calib = np.clip(a_calib * blend_test + b_calib, 0, 1)

    # LOO pentru a estima performanta
    loo = LeaveOneOut()
    preds_loo_raw   = np.zeros(len(y_calib))
    preds_loo_calib = np.zeros(len(y_calib))
    for train_idx, test_idx in loo.split(blend_calib):
        # Fit calibrare pe train (fara test_idx)
        X_tr = blend_calib[train_idx].reshape(-1, 1)
        r = Ridge(alpha=0.1)
        r.fit(X_tr, y_calib[train_idx])
        preds_loo_raw[test_idx]   = blend_calib[test_idx]
        preds_loo_calib[test_idx] = r.predict(blend_calib[test_idx].reshape(-1, 1))[0]

    preds_loo_raw   = np.clip(preds_loo_raw,   0, 1)
    preds_loo_calib = np.clip(preds_loo_calib, 0, 1)

    score_raw   = eval_metric(y_calib, preds_loo_raw)
    score_calib = eval_metric(y_calib, preds_loo_calib)
    pears_raw,   _ = pearsonr(y_calib, preds_loo_raw)
    pears_calib, _ = pearsonr(y_calib, preds_loo_calib)

    print(f"\n  LOO fara calibrare:  Score={score_raw:.2f}  Pearson={pears_raw:+.3f}")
    print(f"  LOO cu calibrare:    Score={score_calib:.2f}  Pearson={pears_calib:+.3f}")

    # =====================================================================
    # TABEL PREDICTII CALIBRARE
    # =====================================================================
    print(f"\n{'Token':15} {'True':6} {'zipf_c':6} {'et_pr':5} {'blend':5} {'calib':5}")
    print("-" * 55)
    tokens = X_calib_df['token'].tolist()
    for i, tok in enumerate(tokens):
        t  = str(tok)[:14]
        tr = y_calib[i]
        zc = zipf_comp_calib[i]
        et = et_v_calib[i] if has_et_calib[i] else float('nan')
        bl = blend_calib[i]
        ca = preds_loo_calib[i]
        et_s = f"{et:.3f}" if not np.isnan(et) else "  nan"
        print(f"{t:15} {tr:.3f}  {zc:.3f}  {et_s}  {bl:.3f}  {ca:.3f}")

    # =====================================================================
    # GENERARE SUBMISII
    # =====================================================================
    print("\n--- Submisii generate ---")

    def save_sub(preds, fname, desc):
        sub = pd.DataFrame({
            'subtaskID':   1,
            'datapointID': test_df['datapointID'],
            'answer':      np.clip(preds, 0.0, 1.0)
        })
        sub.to_csv(f"{OUTPUT_DIR}/{fname}", index=False)
        a = sub['answer']
        print(f"  {fname}: mean={a.mean():.3f} std={a.std():.3f} "
              f"min={a.min():.3f} max={a.max():.3f}  [{desc}]")
        return sub

    # Submisie 1: Blend necalibrat
    save_sub(blend_test, "submission_blend_raw.csv",
             f"Blend(et_w={best_w:.1f})")

    # Submisie 2: Blend calibrat linear pe 14 exemple
    save_sub(pred_test_calib, "submission_blend_calibrated.csv",
             "Blend calibrat")

    # Submisie 3: Pur zipf_token (backup stabil)
    save_sub(zipf_comp_test, "submission_zipf_only.csv",
             "Zipf token only")

    # =====================================================================
    # CALIBRARE Z-SCORE: ajusteaza media si std la distributia calibrarii
    # =====================================================================
    print("\n--- Calibrare z-score (moment matching) ---")
    mean_true = y_calib.mean()
    std_true  = y_calib.std()
    mean_pred = blend_test.mean()
    std_pred  = blend_test.std()
    print(f"  True:      mean={mean_true:.3f}  std={std_true:.3f}")
    print(f"  Pred raw:  mean={mean_pred:.3f}  std={std_pred:.3f}")

    if std_pred > 1e-9:
        blend_zscore = (blend_test - mean_pred) * (std_true / std_pred) + mean_true
    else:
        blend_zscore = np.full_like(blend_test, mean_true)
    blend_zscore = np.clip(blend_zscore, 0, 1)

    save_sub(blend_zscore, "submission_zscore.csv",
             "Z-score calibrated (mean+std matching)")

    # Verifica pe calibrare
    if std_pred > 0:
        bz_c = np.clip((blend_calib - mean_pred) * (std_true/std_pred) + mean_true, 0, 1)
        pz, _ = pearsonr(y_calib, bz_c)
        rz = max(0, r2_score(y_calib, bz_c))
        sz = eval_metric(y_calib, bz_c)
        print(f"  Score pe calib dupa z-score: {sz:.2f}  Pearson={pz:+.3f}  R2={rz:.3f}")

    print(f"\n[PRINCIPAL]  submission_blend_raw.csv (ET proxy + zipf fallback)")
    print(f"[ALTERNATIV] submission_zscore.csv    (z-score calibrated)")
    print(f"[BACKUP]     submission_zipf_only.csv (zipf_token only)")


if __name__ == '__main__':
    main()
