"""
Model de predictie complexitate lexicala din ET data + features lexicale.
Produce: output/submission.csv
"""
import sys
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import r2_score
from scipy.stats import pearsonr

sys.stdout.reconfigure(encoding='utf-8')

DATA_DIR = r"C:\Users\glosper\Documents\pred_eye\data"
OUTPUT_DIR = r"C:\Users\glosper\Documents\pred_eye\output"


def eval_metric(y_true, preds):
    y_true = np.array(y_true, dtype=float)
    preds = np.array(preds, dtype=float)
    if np.std(preds) < 1e-9:
        return 0.0
    r2 = max(0, r2_score(y_true, preds))
    pears = pearsonr(y_true, preds)[0]
    if np.isnan(pears):
        pears = 0.0
    return 100 * (abs(pears) + r2) / 2


def safe_pearson(x, y):
    if np.std(x) < 1e-9 or np.std(y) < 1e-9:
        return 0.0
    r, _ = pearsonr(x, y)
    return r if not np.isnan(r) else 0.0


def loo_predict(X, y, alpha=1.0, model_cls=Ridge):
    loo = LeaveOneOut()
    preds = np.zeros(len(y))
    for train_idx, test_idx in loo.split(X):
        pipe = Pipeline([('sc', StandardScaler()), ('m', model_cls(alpha=alpha))])
        pipe.fit(X[train_idx], y[train_idx])
        preds[test_idx] = pipe.predict(X[test_idx])
    return np.clip(preds, 0, 1)


def build_features_for_model(df, cols):
    X_parts = []
    for col in cols:
        if col not in df.columns:
            X_parts.append(np.zeros(len(df)))
            continue
        vals = df[col].values.astype(float)
        nan_m = np.isnan(vals)
        if nan_m.all():
            X_parts.append(np.zeros(len(df)))
        else:
            vals[nan_m] = np.nanmean(vals)
            X_parts.append(vals)
    return np.column_stack(X_parts)


def main():
    print("=" * 60)
    print("MODEL COMPLEXITATE LEXICALA")
    print("=" * 60)

    X_test_df  = pd.read_csv(f"{DATA_DIR}/X_test.csv")
    X_calib_df = pd.read_csv(f"{DATA_DIR}/X_calib.csv")
    word_features = pd.read_csv(f"{DATA_DIR}/word_features.csv")
    test_aligned  = pd.read_csv(f"{DATA_DIR}/test_aligned.csv")
    calib_aligned = pd.read_csv(f"{DATA_DIR}/calib_aligned.csv")
    test_df = pd.read_csv(f"{DATA_DIR}/test_set.csv")

    y_calib = X_calib_df['complexity'].values
    tokens_calib = X_calib_df['token'].tolist()

    print(f"\nCalibrate: {len(y_calib)} exemple | "
          f"y: min={y_calib.min():.3f} max={y_calib.max():.3f} mean={y_calib.mean():.3f}")

    # ======================================================
    # Analiza corelatie features cu complexitate
    # ======================================================
    print("\n--- Corelatie features-complexitate (14 exemple) ---")
    corr_features = ['word_length', 'num_syllables', 'zipf_token', 'zipf_lemma',
                     'neg_zipf', 'log_freq', 'is_oov', 'et_complexity_proxy',
                     'skip_rate_norm', 'TFT_mean_norm', 'FFD_mean_norm', 'RRT_mean_norm',
                     'inflection_diff', 'has_diacritice']
    for feat in corr_features:
        if feat in X_calib_df.columns:
            vals = X_calib_df[feat].fillna(X_calib_df[feat].mean()).values.astype(float)
            r = safe_pearson(vals, y_calib)
            print(f"  {feat:30s}: Pearson={r:+.3f}")

    # ======================================================
    # METODA A: ET Proxy normalizat pe word_features
    # ======================================================
    print("\n--- Metoda A: ET Proxy (normalizat pe corpus ET) ---")

    weights = {'TFT_mean': 0.30, 'RRT_mean': 0.20, 'FFD_mean': 0.14,
               'RPD_inc_mean': 0.10, 'TRC_in_mean': 0.08, 'FPFC_mean': 0.07,
               'TFC_mean': 0.05, 'skip_rate': -0.10}

    def compute_et_proxy_df(df_aligned):
        has_et = df_aligned['TFT_mean'].notna()
        proxy = pd.Series(np.nan, index=df_aligned.index)
        if has_et.sum() == 0:
            return proxy
        scores = pd.DataFrame(index=df_aligned[has_et].index)
        for col, w in weights.items():
            if col not in df_aligned.columns or col not in word_features.columns:
                continue
            mn = word_features[col].quantile(0.01)
            mx = word_features[col].quantile(0.99)
            vals = df_aligned.loc[has_et, col].fillna(0)
            if mx == mn:
                norm = pd.Series(0.5, index=vals.index)
            else:
                norm = ((vals - mn) / (mx - mn)).clip(0, 1)
            scores[col] = norm * abs(w) if w > 0 else (1 - norm) * abs(w)
        proxy[has_et] = scores.sum(axis=1).clip(0, 1)
        return proxy

    et_proxy_test  = compute_et_proxy_df(test_aligned)
    et_proxy_calib = compute_et_proxy_df(calib_aligned)

    has_et_c = et_proxy_calib.notna()
    if has_et_c.sum() >= 2:
        r_et = safe_pearson(et_proxy_calib[has_et_c].values, y_calib[has_et_c.values])
        print(f"  Pearson ET proxy (n={has_et_c.sum()}): {r_et:+.3f}")

    et_median = et_proxy_test.median()
    pred_A = et_proxy_test.fillna(et_median).values

    # ======================================================
    # METODA B: zipf_token pur (inversat si normalizat)
    # ======================================================
    print("\n--- Metoda B: neg_zipf_token Ridge (alpha grid) ---")

    # Folosim zipf_token (nu best) pentru a capta raritatea formei flexionate
    freq_cols_simple = ['zipf_token']
    X_freq_calib = build_features_for_model(X_calib_df, freq_cols_simple)
    X_freq_test  = build_features_for_model(X_test_df,  freq_cols_simple)

    best_score_b, best_alpha_b = -999, 1.0
    for alpha in [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0]:
        preds_loo = loo_predict(X_freq_calib, y_calib, alpha=alpha)
        score = eval_metric(y_calib, preds_loo)
        pears = safe_pearson(preds_loo, y_calib)
        if score > best_score_b:
            best_score_b, best_alpha_b = score, alpha
    print(f"  Cel mai bun alpha: {best_alpha_b}, Score LOO: {best_score_b:.2f}")

    preds_loo_b = loo_predict(X_freq_calib, y_calib, alpha=best_alpha_b)
    pears_b = safe_pearson(preds_loo_b, y_calib)
    print(f"  Pearson LOO: {pears_b:+.3f}")

    model_b = Pipeline([('sc', StandardScaler()), ('m', Ridge(alpha=best_alpha_b))])
    model_b.fit(X_freq_calib, y_calib)
    pred_B = np.clip(model_b.predict(X_freq_test), 0, 1)

    # ======================================================
    # METODA C: Features lexicale + freq (toate)
    # ======================================================
    print("\n--- Metoda C: Features lexicale + freq Ridge ---")

    lex_freq_cols = ['word_length', 'num_syllables', 'zipf_token', 'zipf_lemma',
                     'avg_syllable_length', 'inflection_diff', 'has_diacritice',
                     'vowel_ratio', 'is_oov', 'log_freq', 'ends_with_vowel']
    X_lex_calib = build_features_for_model(X_calib_df, lex_freq_cols)
    X_lex_test  = build_features_for_model(X_test_df,  lex_freq_cols)

    best_score_c, best_alpha_c = -999, 1.0
    for alpha in [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0]:
        preds_loo = loo_predict(X_lex_calib, y_calib, alpha=alpha)
        score = eval_metric(y_calib, preds_loo)
        if score > best_score_c:
            best_score_c, best_alpha_c = score, alpha
    print(f"  Cel mai bun alpha: {best_alpha_c}, Score LOO: {best_score_c:.2f}")

    preds_loo_c = loo_predict(X_lex_calib, y_calib, alpha=best_alpha_c)
    pears_c = safe_pearson(preds_loo_c, y_calib)
    print(f"  Pearson LOO: {pears_c:+.3f}")

    model_c = Pipeline([('sc', StandardScaler()), ('m', Ridge(alpha=best_alpha_c))])
    model_c.fit(X_lex_calib, y_calib)
    pred_C = np.clip(model_c.predict(X_lex_test), 0, 1)

    # ======================================================
    # METODA D: ET + Freq combinate
    # ======================================================
    print("\n--- Metoda D: ET + Freq + Lex ---")

    et_lex_cols = lex_freq_cols + [
        'et_complexity_proxy', 'TFT_mean_norm', 'RRT_mean_norm',
        'FFD_mean_norm', 'skip_rate_norm', 'TRC_in_mean_norm',
        'tft_per_fixation_norm', 'TFT_cv_norm'
    ]
    X_etlex_calib = build_features_for_model(X_calib_df, et_lex_cols)
    X_etlex_test  = build_features_for_model(X_test_df,  et_lex_cols)

    best_score_d, best_alpha_d = -999, 1.0
    for alpha in [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0]:
        preds_loo = loo_predict(X_etlex_calib, y_calib, alpha=alpha)
        score = eval_metric(y_calib, preds_loo)
        if score > best_score_d:
            best_score_d, best_alpha_d = score, alpha
    print(f"  Cel mai bun alpha: {best_alpha_d}, Score LOO: {best_score_d:.2f}")

    preds_loo_d = loo_predict(X_etlex_calib, y_calib, alpha=best_alpha_d)
    pears_d = safe_pearson(preds_loo_d, y_calib)
    print(f"  Pearson LOO: {pears_d:+.3f}")

    model_d = Pipeline([('sc', StandardScaler()), ('m', Ridge(alpha=best_alpha_d))])
    model_d.fit(X_etlex_calib, y_calib)
    pred_D = np.clip(model_d.predict(X_etlex_test), 0, 1)

    # ======================================================
    # METODA E: Zipf + ET proxy (blend simplu, fara model)
    # ======================================================
    print("\n--- Metoda E: Blend Zipf + ET proxy (no-fit) ---")
    # Normalizeaza zipf_token pe test set → scor de complexitate
    zt = X_test_df['zipf_token'].fillna(3.0).values.astype(float)
    zt_max, zt_min = zt.max(), zt.min()
    zipf_complexity = 1 - (zt - zt_min) / (zt_max - zt_min + 1e-9)

    et_proxy_filled = et_proxy_test.fillna(et_proxy_test.median()).values
    alpha_blend = 0.5
    pred_E = alpha_blend * et_proxy_filled + (1 - alpha_blend) * zipf_complexity
    pred_E = np.clip(pred_E, 0, 1)

    # Valideaza pe calibrare
    zt_c = X_calib_df['zipf_token'].fillna(3.0).values.astype(float)
    zipf_comp_c = 1 - (zt_c - zt_min) / (zt_max - zt_min + 1e-9)
    et_proxy_c_filled = et_proxy_calib.fillna(et_proxy_calib.median()).values
    pred_E_c = 0.5 * et_proxy_c_filled + 0.5 * zipf_comp_c
    score_e = eval_metric(y_calib, np.clip(pred_E_c, 0, 1))
    pears_e = safe_pearson(np.clip(pred_E_c, 0, 1), y_calib)
    print(f"  Score LOO (proxy): {score_e:.2f}, Pearson: {pears_e:+.3f}")

    # ======================================================
    # REZUMAT
    # ======================================================
    print("\n" + "=" * 60)
    print("REZUMAT SCORURI (LOO pe 14 exemple):")
    print(f"  Metoda A (ET proxy pur):           N/A (2 exemple)")
    print(f"  Metoda B (zipf_token Ridge):       {best_score_b:.2f}")
    print(f"  Metoda C (lex+freq Ridge):         {best_score_c:.2f}")
    print(f"  Metoda D (ET+freq+lex Ridge):      {best_score_d:.2f}")
    print(f"  Metoda E (blend zipf+ET, no-fit):  {score_e:.2f}")

    # Alege cel mai bun model pe baza LOO
    scores_map = {'B': (best_score_b, pred_B), 'C': (best_score_c, pred_C),
                  'D': (best_score_d, pred_D), 'E': (score_e, pred_E)}
    best_method = max(scores_map, key=lambda k: scores_map[k][0])
    print(f"\n  Cel mai bun LOO: Metoda {best_method} ({scores_map[best_method][0]:.2f})")

    # ======================================================
    # Generare submisii
    # ======================================================
    def save_sub(preds, fname, desc):
        sub = pd.DataFrame({
            'subtaskID': 1,
            'datapointID': test_df['datapointID'],
            'answer': np.clip(preds, 0.0, 1.0)
        })
        sub.to_csv(f"{OUTPUT_DIR}/{fname}", index=False)
        print(f"  Salvat {fname}: answer mean={sub['answer'].mean():.3f} "
              f"std={sub['answer'].std():.3f}  [{desc}]")

    print("\n--- Fisiere submission ---")
    save_sub(pred_A, "submission_et_proxy.csv",   "ET proxy pur")
    save_sub(pred_B, "submission_zipf.csv",        "zipf_token Ridge")
    save_sub(pred_C, "submission_lex_freq.csv",    "lex+freq Ridge")
    save_sub(pred_D, "submission_et_lex_freq.csv", "ET+lex+freq Ridge")
    save_sub(pred_E, "submission_blend.csv",       "Blend zipf+ET")

    # ======================================================
    # Tabel de predictii pe calibrare
    # ======================================================
    print("\n\nPREDICTII PE 14 EXEMPLE CALIBRARE:")
    print(f"{'Token':15} {'True':6} {'ETprx':5} {'B_zipf':6} {'C_lex':5} {'D_all':5} {'E_bld':5}")
    print("-" * 60)

    # LOO predictions pentru calibrare
    et_c_v   = np.clip(et_proxy_calib.values, 0, 1)
    pred_D_c = np.clip(loo_predict(X_etlex_calib, y_calib, alpha=best_alpha_d), 0, 1)

    for i, tok in enumerate(tokens_calib):
        t = str(tok)[:14]
        tr = y_calib[i]
        a  = et_c_v[i] if not np.isnan(et_c_v[i]) else float('nan')
        b  = preds_loo_b[i]
        c  = preds_loo_c[i]
        d  = pred_D_c[i]
        e  = np.clip(pred_E_c[i], 0, 1)
        a_s = f"{a:.3f}" if not np.isnan(a) else "  nan"
        print(f"{t:15} {tr:.3f}  {a_s}  {b:.3f}  {c:.3f}  {d:.3f}  {e:.3f}")


if __name__ == '__main__':
    main()
